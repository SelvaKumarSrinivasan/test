﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelMacroAutomation
{
    class Program
    {
        static void Main(string[] args)
        {

            FileInfo fi = new FileInfo(@"C:\Users\selva\Desktop\Barclays.xlsx");
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage excelPackage = new ExcelPackage(fi))
            {
                ExcelWorksheet namedWorksheet = excelPackage.Workbook.Worksheets["Sheet1"];
                namedWorksheet.Cells["C6"].Value = 2000;
                namedWorksheet.Cells["C7"].Value = 3000;
                namedWorksheet.Cells["C8"].Value = 1;
                namedWorksheet.Cells["C9"].Value = 1;
                namedWorksheet.Cells["G6"].Value = 5000;
                namedWorksheet.Cells["H6"].Value = 6000;
                namedWorksheet.Cells["L6"].Value = 7000;
                namedWorksheet.Cells["L7"].Value = 8000;
                namedWorksheet.Cells["L8"].Value =50;
                namedWorksheet.Cells["G9"].Value = 2;
                namedWorksheet.Cells["H9"].Value = 2;
                namedWorksheet.Cells["G11"].Value = 'N';
                namedWorksheet.Cells["H11"].Value = 'N';
                namedWorksheet.Cells["J15"].Value = 15000;
                excelPackage.Save();
                
                //string valB1 = namedWorksheet.Cells["C5"].Value.ToString();
                //excelPackage.Save();
                ////ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                ////using (ExcelPackage excelPackage1 = new ExcelPackage(fi))
                ////{

                ////    //Get a WorkSheet by name. If the worksheet doesn't exist, throw an exeption
                ////    ExcelWorksheet namedWorksheet1 = excelPackage.Workbook.Worksheets["Sheet1"];

                ////    ////If you don't know if a worksheet exists, you could use LINQ,
                ////    ////So it doesn't throw an exception, but return null in case it doesn't find it
                ////    //ExcelWorksheet anotherWorksheet 

                ////    Console.WriteLine(namedWorksheet1.Cells["C8"].Value.ToString());
                ////    //Save your file
                ////    excelPackage.Save();
                ////}

            }
        }
    }
}
